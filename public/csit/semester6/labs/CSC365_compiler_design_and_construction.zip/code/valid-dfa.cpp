 98888888.333333333333333333333333333#include <cstring>
#include <iostream>
using namespace std;

void checkValidDFA(string s)
{
    // Stores initial state of DFA
    int initial_state = 0;
    // Stores previous state of DFA
    int previous_state = initial_state;
    // Stores final state of DFA
    int final_state;
    // Iterate through the string
    for (int i = 0; i < s.length(); i++) {
        // Checking for all combinations
        if ((previous_state == 0 && s[i] == 'a') ||
        (previous_state == 1 && s[i] == 'a')) {
            final_state = 1;
        }
        if ((previous_state == 0 && s[i] == 'b') ||
        (previous_state == 2 && s[i] == 'b')) {
            final_state = 0;
        }
        if (previous_state == 1 && s[i] == 'b') {
        final_state = 2;
        }
        if ((previous_state == 2 && s[i] == 'a') ||
        (previous_state == 3)) {
            final_state = 3;
        }
        // Update the previous_state
        previous_state = final_state;
    }
    // If final state is reached
    if (final_state == 3) {
        cout << s+" => Accepted" << endl;
    }
    // Otherwise
    else {
        cout << s+" => Rejected" << endl;
    }
}

int main()
{
	string dfa;
	char a;
	do{
	cout<<"Enter a string:";
	cin>>dfa;
    // Check for "ababa"
    checkValidDFA(dfa);
    cout<<"do you want to continue:";
    cin>>a;
	}while(a=='y' || a=='Y');
    return 0;
} 
