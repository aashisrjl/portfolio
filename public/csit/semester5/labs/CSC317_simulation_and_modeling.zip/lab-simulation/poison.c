#include <stdio.h>

int main() {
    float l, m, e;
    float p, et;

    // Prompt for input
    printf("Enter Inter-arrival time of customers per hour: ");
    scanf("%f", &l);

    printf("Enter the average time spent by customers per hour: ");
    scanf("%f", &m);

    // Check for division by zero
    if (m == l) {
        printf("Error: Arrival rate cannot be equal to service rate.\n");
        return 1;
    }

    // Calculate values
    p = 1 - l / m;
    e = l / (m - l);
    et = 1 / (m - l) * 60;

    // Print results
    printf("\nThe probability that a customer won’t have to wait at the counter: %.2f", p);
    printf("\nExpected number of customers: %.2f", e);
    printf("\nExpected time to be spent in bank: %.2f minutes\n", et);

    return 0;
}
