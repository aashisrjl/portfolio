#include<stdio.h>
#include<math.h>
#include<time.h>
#include<stdlib.h>

int main() {
    srand(time(NULL)); // Seed the random number generator with the current time
    unsigned int i, n, N;
    float x, y, r, pi;

    printf("Total Samples = ");
    scanf("%d", &N);

    n = 0;
    for(i = 0; i < N; i++) {
        x = (double)rand() / (RAND_MAX);
        y = (double)rand() / (RAND_MAX);
        r = x * x + y * y;
        if(r <= 1)
            n++;
    }

    pi = (double)n / N * 4;

    printf("Actual PI value: 3.141549045...\n");
    printf("Approx PI = %f\n", pi);
    printf("Error in percent: %f percent\n", fabs((3.141549045 - pi) * 100 / 3.141549045));

    return 0;
}