#include <stdio.h>
#include <math.h>

int main() {
    float l, pr;
    int x, i, factorial;

    // Input: Arrival rate
    printf("Enter arrival rate per hour: ");
    scanf("%f", &l);

    // Poisson distribution calculation
    for (x = 0; x < 16; x++) {
        factorial = 1;

        // Compute factorial of x
        for (i = 1; i <= x; i++) {
            factorial *= i;
        }

        // Poisson probability formula: P(X=x) = (e^(-λ) * λ^x) / x!
        pr = (pow(2.71828, -l) * pow(l, x)) / factorial;

        // Output result
        printf("P(X=%d) = %f\n", x, pr);
    }

    return 0;
}
