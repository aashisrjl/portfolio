#include <stdio.h>
int main()
{
    int seed;
    int i, n, random;
    printf("Enter Seed: ");
    scanf("%d", &seed);
    printf("How many number you want to generate : ");
    scanf("%d", &n);
    printf("Random Numbers are : ");
    for (i = 0; i < n; i++)
    {
        seed = seed * seed;
        seed = seed / 100;   // Take the dividend
        seed = seed % 10000; // Take the reminder
        random = seed;
        printf("%d ", random);
    }
    printf("\n");
    return 0;
}