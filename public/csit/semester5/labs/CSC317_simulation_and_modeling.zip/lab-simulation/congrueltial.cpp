#include <stdio.h>
#define SIZE 100
int main()
{
    int x[SIZE], i, m, a, c;
    printf("Enter m, a, c and x[0]: ");
    scanf("%d %d %d %d", &m, &a, &c, &x[0]);
    for (i = 0; i < 100; i++)
        x[i + 1] = (a * x[i] + c) % m;
    printf("Generation of random numbers using linear congruential method\n");
    for (i = 0; i < 20; i++)
        printf("%d\t", x[i]);
    return 0;
}