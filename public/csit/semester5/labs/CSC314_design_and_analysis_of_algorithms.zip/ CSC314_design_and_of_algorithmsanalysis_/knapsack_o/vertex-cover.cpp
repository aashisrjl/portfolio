#include <stdio.h>
#include <stdlib.h>

// Structure to represent an edge
struct Edge {
    int u, v;
};

// Function to perform the 2-approximation algorithm for vertex cover
void vertexCover(int graph[][5], int V) {
    int visited[V];  // Array to keep track of visited vertices
    for (int i = 0; i < V; i++) {
        visited[i] = 0;
    }

    // Print the vertex cover set
    printf("Vertex Cover Set: ");

    // Iterate over all edges
    for (int u = 0; u < V; u++) {
        for (int v = u + 1; v < V; v++) {
            // If there is an edge between u and v and neither u nor v is visited
            if (graph[u][v] == 1 && visited[u] == 0 && visited[v] == 0) {
                // Add u and v to the vertex cover set
                printf("%d %d ", u, v);
                visited[u] = 1;
                visited[v] = 1;
            }
        }
    }

    printf("\n");
}

// Driver code
int main() {
    // Example graph (adjacency matrix)
    // Here, 5 vertices (0 to 4), with edges represented as 1
    int graph[5][5] = {
        {0, 1, 1, 0, 0},
        {1, 0, 1, 1, 0},
        {1, 1, 0, 1, 1},
        {0, 1, 1, 0, 1},
        {0, 0, 1, 1, 0}
    };

    int V = 5;  // Number of vertices

    // Call the 2-approximation algorithm
    vertexCover(graph, V);

    return 0;
}
