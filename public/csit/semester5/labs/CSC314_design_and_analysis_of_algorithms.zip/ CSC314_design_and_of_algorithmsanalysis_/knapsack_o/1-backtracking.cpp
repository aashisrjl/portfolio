#include <stdio.h>

// Function to solve 0/1 Knapsack problem using Backtracking
int knapsack(int W, int wt[], int val[], int n, int i, int totalValue, int totalWeight) {
    // Base condition: If we have considered all items or if total weight exceeds capacity
    if (i == n || totalWeight > W) {
        return totalValue;
    }
    
    // Include the current item in the knapsack
    int include = 0;
    if (totalWeight + wt[i] <= W) {
        include = knapsack(W, wt, val, n, i + 1, totalValue + val[i], totalWeight + wt[i]);
    }
    
    // Exclude the current item from the knapsack
    int exclude = knapsack(W, wt, val, n, i + 1, totalValue, totalWeight);
    
    // Return the maximum value obtained by including or excluding the current item
    return (include > exclude) ? include : exclude;
}

int main() {
    int n, W;

    // Take input from the user for the number of items and the knapsack capacity
    printf("Enter the number of items: ");
    scanf("%d", &n);
    printf("Enter the capacity of the knapsack: ");
    scanf("%d", &W);
    
    int wt[n], val[n];
    
    // Take input for the values and weights of the items
    printf("Enter the weights of the items: \n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &wt[i]);
    }
    
    printf("Enter the values of the items: \n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &val[i]);
    }
    
    // Function call to get the maximum value that can be achieved
    int result = knapsack(W, wt, val, n, 0, 0, 0);
    
    // Output the result
    printf("Maximum value in knapsack = %d\n", result);

    return 0;
}
