#include <stdio.h>
#include <stdbool.h>

#define N 8  // You can change N for different board sizes

// Function to check if a queen can be placed on the board
bool isSafe(int board[N][N], int row, int col) {
    int i, j;

    // Check the column for previous queens
    for (i = 0; i < row; i++) {
        if (board[i][col] == 1) {
            return false;
        }
    }

    // Check the upper left diagonal
    for (i = row, j = col; i >= 0 && j >= 0; i--, j--) {
        if (board[i][j] == 1) {
            return false;
        }
    }

    // Check the upper right diagonal
    for (i = row, j = col; i >= 0 && j < N; i--, j++) {
        if (board[i][j] == 1) {
            return false;
        }
    }

    return true;
}

// Function to solve the N-Queens problem using backtracking
bool solveNQueens(int board[N][N], int row) {
    // If all queens are placed, return true
    if (row >= N) {
        return true;
    }

    // Try placing a queen in each column one by one
    for (int col = 0; col < N; col++) {
        // Check if placing queen at board[row][col] is safe
        if (isSafe(board, row, col)) {
            // Place the queen
            board[row][col] = 1;

            // Recur to place the rest of the queens
            if (solveNQueens(board, row + 1)) {
                return true;
            }

            // Backtrack by removing the queen
            board[row][col] = 0;
        }
    }

    // If no place is found for the queen, return false
    return false;
}

// Function to print the chessboard
void printBoard(int board[N][N]) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            printf(board[i][j] ? "Q " : ". ");
        }
        printf("\n");
    }
}

int main() {
    int board[N][N] = {0};  // Initialize the chessboard with 0 (no queens)

    // Try to solve the N-Queens problem
    if (solveNQueens(board, 0)) {
        printf("Solution found:\n");
        printBoard(board);
    } else {
        printf("No solution exists\n");
    }

    return 0;
}
