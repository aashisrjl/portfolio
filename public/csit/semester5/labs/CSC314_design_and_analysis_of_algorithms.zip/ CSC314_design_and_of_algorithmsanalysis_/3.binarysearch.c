//binary search
#include <stdio.h>

// Binary Search (Recursive)
int binarySearchRecursive(int arr[], int left, int right, int target) {
    if (left <= right) {
        int mid = left + (right - left) / 2;
        if (arr[mid] == target) return mid;
        else if (arr[mid] < target) return binarySearchRecursive(arr, mid + 1, right, target);
        else return binarySearchRecursive(arr, left, mid - 1, target);
    }
    return -1;
}
// Time Complexity: O(log n)
// Space Complexity: O(log n) due to recursive stack

int main() {
    int size;
    printf("Enter the size of the array: ");
    scanf("%d", &size);

    int arr[size];
    printf("Enter %d sorted elements: ", size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &arr[i]);
    }

    int target;
    printf("Enter the target element: ");
    scanf("%d", &target);

    int result = binarySearchRecursive(arr, 0, size - 1, target);
    if (result != -1)
        printf("Element %d found at index: %d\n", target, result);
    else
        printf("Element %d not found.\n", target);

    return 0;
}
