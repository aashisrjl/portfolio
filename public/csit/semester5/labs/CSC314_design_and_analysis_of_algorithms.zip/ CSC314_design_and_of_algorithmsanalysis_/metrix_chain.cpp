#include <limits.h>
#include <stdio.h>

// Matrix Ai has dimension p[i-1] x p[i] 
// for i = 1 . . . n
int MatrixChainOrder(int p[], int i, int j)
{
    if (i == j)
        return 0;
    int k;
    int min = INT_MAX;
    int count;


    for (k = i; k < j; k++) 
    {
        count = MatrixChainOrder(p, i, k)
                + MatrixChainOrder(p, k + 1, j)
                + p[i - 1] * p[k] * p[j];

        if (count < min)
            min = count;
    }

    // Return minimum count
    return min;
}

int main()
{
    int n;
    
    // Take the number of matrices (n-1) from the user
    printf("Enter the number of matrices: ");
    scanf("%d", &n);
    
    // Create the array for dimensions of the matrices
    int arr[n + 1];
    
    // Take dimensions from the user
    printf("Enter the dimensions of the matrices: \n");
    for (int i = 0; i < n + 1; i++) {
        printf("p[%d]: ", i);
        scanf("%d", &arr[i]);
    }

    // Function call to calculate the minimum number of multiplications
    printf("Minimum number of multiplications is %d\n", MatrixChainOrder(arr, 1, n - 1));
    
    return 0;
}

