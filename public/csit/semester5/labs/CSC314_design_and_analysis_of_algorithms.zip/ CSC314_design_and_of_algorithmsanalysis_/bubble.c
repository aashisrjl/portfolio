#include <stdio.h>
#include <time.h>

// Function to swap two elements
void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

// Function to print the array
void printArray(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

// Bubble Sort implementation
void bubbleSort(int arr[], int size) {
    for (int i = 0; i < size - 1; i++) {
        // Last i elements are already in place
        for (int j = 0; j < size - i - 1; j++) {
            // Compare adjacent elements and swap if they are in wrong order
            if (arr[j] > arr[j + 1]) {
                swap(&arr[j], &arr[j + 1]);
            }
        }
    }
}

int main() {
    int size;
    clock_t start, end;
    double time_taken;
    
    // Input the size of the array
    printf("Enter the size of the array: ");
    scanf("%d", &size);
    
    int arr[size];
    // Input the array elements
    printf("Enter %d elements:\n", size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &arr[i]);
    }
    

    // Print the original array
    printf("\nOriginal array: ");
    printArray(arr, size);
    
    start = clock();
    // Sort the array using Bubble Sort
    bubbleSort(arr, size);
    end = clock();
    time_taken = ((double)(end - start)) / CLOCKS_PER_SEC;
    
    // Print the sorted array
    printf("Sorted array (Bubble Sort): ");
    printArray(arr, size);
    printf("Time taken to perform the task : %.10f seconds\n", time_taken);
    
    return 0;
}