#include <stdio.h>
#include <stdlib.h>

// Function to compare jobs based on profit (for sorting)
int compare(const void *a, const void *b) {
    int *jobA = (int *)a;
    int *jobB = (int *)b;
    return (jobB[2] - jobA[2]);
}

// Function to solve the job sequencing problem with deadlines
void jobSequencing(int jobs[][3], int n) {
    // Sort jobs in descending order of profit
    qsort(jobs, n, sizeof(jobs[0]), compare);

    int maxDeadline = 0;
    for (int i = 0; i < n; i++) {
        if (jobs[i][1] > maxDeadline) {
            maxDeadline = jobs[i][1];
        }
    }

    int result[maxDeadline];
    for (int i = 0; i < maxDeadline; i++) {
        result[i] = -1;
    }

    int totalProfit = 0;

    for (int i = 0; i < n; i++) {
        for (int j = jobs[i][1] - 1; j >= 0; j--) {
            if (result[j] == -1) {
                result[j] = i;
                totalProfit += jobs[i][2];
                break;
            }
        }
    }

    printf("Job sequence: ");
    for (int i = 0; i < maxDeadline; i++) {
        if (result[i] != -1) {
            printf("%d ", jobs[result[i]][0]);
        }
    }
    printf("\nTotal profit: %d\n", totalProfit);
}

int main() {
    int n;
    printf("Enter number of jobs: ");
    scanf("%d", &n);

    int jobs[n][3]; // Each job: ID, Deadline, Profit

    printf("Enter Job ID, Deadline and Profit for each job:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d %d %d", &jobs[i][0], &jobs[i][1], &jobs[i][2]);
    }

    jobSequencing(jobs, n);

    return 0;
}
