#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Function to swap two elements
void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

// Function to generate a random index between low and high
int randomPivot(int low, int high) {
    return low + rand() % (high - low + 1);
}

// Function to partition the array using a random pivot
int partition(int arr[], int low, int high) {
    // Choose a random pivot and swap it with the last element
    int pivotIndex = randomPivot(low, high);
    swap(&arr[pivotIndex], &arr[high]);
    
    int pivot = arr[high];    // Now the pivot is the last element
    int i = low - 1;          // Index of smaller element
    
    for (int j = low; j < high; j++) {
        // If current element is smaller than or equal to pivot
        if (arr[j] <= pivot) {
            i++; // Increment index of smaller element
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    return i + 1; // Return the partition index
}

// Function to perform Randomized Quick Sort
void randomizedQuickSort(int arr[], int low, int high) {
    if (low < high) {
        // Find the partition index
        int pi = partition(arr, low, high);
        // Recursively sort elements before and after partition
        randomizedQuickSort(arr, low, pi - 1);
        randomizedQuickSort(arr, pi + 1, high);
    }
}

// Function to print the array
void printArray(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int main() {
    // Seed the random number generator
    srand(time(0));
    
    int size;
    clock_t start, end;
    double time_taken;
    
    // Input the size of the array
    printf("Enter the size of the array: ");
    scanf("%d", &size);
    
    int arr[size];
    // Input the array elements
    printf("Enter %d elements:\n", size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &arr[i]);
    }
    
    // Print the original array
    printf("\nOriginal array: ");
    printArray(arr, size);
    
    start = clock();
    // Sort the array using Randomized Quick Sort
    randomizedQuickSort(arr, 0, size - 1);
    end = clock();
    time_taken = ((double)(end - start)) / CLOCKS_PER_SEC;
    
    // Print the sorted array
    printf("Sorted array (Randomized Quick Sort): ");
    printArray(arr, size);
    printf("Time taken to sort the array: %f seconds\n", time_taken);
    
    return 0;
}