#include <stdio.h>
#include <stdlib.h>

// Function to compare items based on value-to-weight ratio (for sorting)
int compare(const void *a, const void *b) {
    double *itemA = (double *)a;
    double *itemB = (double *)b;
    return (itemB[2] > itemA[2]) - (itemB[2] < itemA[2]);
}

// Function to solve the fractional knapsack problem
double fractionalKnapsack(int weights[], int values[], int n, int capacity) {
    double items[n][3]; // Each item: weight, value, ratio

    // Calculate value-to-weight ratio for each item
    for (int i = 0; i < n; i++) {
        items[i][0] = weights[i];
        items[i][1] = values[i];
        items[i][2] = (double)values[i] / weights[i];
    }

    // Sort items in descending order of ratio
    qsort(items, n, sizeof(items[0]), compare);

    double totalValue = 0.0; // Total value accumulated

    // Loop through sorted items and add them to the knapsack
    for (int i = 0; i < n; i++) {
        if (capacity >= items[i][0]) {
            // Take full item
            capacity -= items[i][0];
            totalValue += items[i][1];
        } else {
            // Take fractional item
            totalValue += items[i][2] * capacity;
            break;  // Knapsack is full
        }
    }
    return totalValue;
}

int main() {
    int n, capacity;
    printf("Enter number of items: ");
    scanf("%d", &n);

    int weights[n], values[n];

    printf("Enter weight and value of each item:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d %d", &weights[i], &values[i]);
    }

    printf("Enter knapsack capacity: ");
    scanf("%d", &capacity);

    double maxValue = fractionalKnapsack(weights, values, n, capacity);
    printf("Maximum value in the knapsack: %.2lf\n", maxValue);

    return 0;
}
