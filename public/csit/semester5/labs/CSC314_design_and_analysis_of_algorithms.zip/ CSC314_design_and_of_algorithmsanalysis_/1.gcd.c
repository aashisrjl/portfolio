#include <stdio.h>

// GCD Algorithm (Iterative)
int gcd(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}
// Time Complexity: O(log(min(a, b)))
// Space Complexity: O(1)

int main() {
    int a, b;
    printf("Enter two numbers: ");
    scanf("%d %d", &a, &b);
    if (a < 0 || b < 0) {
        printf("Please enter non-negative integers.\n");
        return 1;
    }
    printf("GCD of %d and %d is: %d\n", a, b, gcd(a, b));
    return 0;
}