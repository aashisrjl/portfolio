#include <stdio.h>
#include <stdlib.h>

// Maximum height of the Huffman Tree (for storing codes)
#define MAX_HEIGHT 100

// Structure for a Huffman tree node
typedef struct MinHeapNode {
    char data;          // Character
    unsigned freq;      // Frequency of the character
    struct MinHeapNode *left, *right; // Left and right children
} MinHeapNode;

// Structure for the min-heap
typedef struct MinHeap {
    MinHeapNode **array; // Array of pointers to nodes
    int size;            // Current size of the heap
    int capacity;        // Maximum capacity of the heap
} MinHeap;

// Function to create a new Huffman tree node
MinHeapNode* newNode(char data, unsigned freq) {
    MinHeapNode* node = (MinHeapNode*)malloc(sizeof(MinHeapNode));
    node->left = node->right = NULL;
    node->data = data;
    node->freq = freq;
    return node;
}

// Function to create a min-heap
MinHeap* createMinHeap(int capacity) {
    MinHeap* minHeap = (MinHeap*)malloc(sizeof(MinHeap));
    minHeap->size = 0;
    minHeap->capacity = capacity;
    minHeap->array = (MinHeapNode**)malloc(capacity * sizeof(MinHeapNode*));
    return minHeap;
}

// Function to swap two MinHeapNode pointers
void swapNodes(MinHeapNode** a, MinHeapNode** b) {
    MinHeapNode* temp = *a;
    *a = *b;
    *b = temp;
}

// Function to heapify the min-heap at index i
void minHeapify(MinHeap* minHeap, int i) {
    int smallest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < minHeap->size && minHeap->array[left]->freq < minHeap->array[smallest]->freq) {
        smallest = left;
    }
    if (right < minHeap->size && minHeap->array[right]->freq < minHeap->array[smallest]->freq) {
        smallest = right;
    }

    if (smallest != i) {
        swapNodes(&minHeap->array[i], &minHeap->array[smallest]);
        minHeapify(minHeap, smallest);
    }
}

//////bakiiiiiiiiiiiiiiiiiiiiiiiiiiiii

// Function to extract the minimum node from the heap
MinHeapNode* extractMin(MinHeap* minHeap) {
    if (minHeap->size == 0) return NULL;

    MinHeapNode* min = minHeap->array[0];
    minHeap->array[0] = minHeap->array[minHeap->size - 1];
    minHeap->size--;
    minHeapify(minHeap, 0);

    return min;
}

// Function to insert a node into the min-heap
void insertMinHeap(MinHeap* minHeap, MinHeapNode* node) {
    minHeap->size++;
    int i = minHeap->size - 1;

    // Fix the heap property by moving the node up
    while (i > 0 && minHeap->array[(i - 1) / 2]->freq > node->freq) {
        minHeap->array[i] = minHeap->array[(i - 1) / 2];
        i = (i - 1) / 2;
    }
    minHeap->array[i] = node;
}

// Function to print Huffman codes by traversing the tree
void printCodes(MinHeapNode* root, char code[], int top) {
    if (!root) return;

    // If this is a leaf node, print the character and its code
    if (root->data != '$') {
        code[top] = '\0';
        printf("%c: %s\n", root->data, code);
    }

    // Traverse left (add 0)
    if (root->left) {
        code[top] = '0';
        printCodes(root->left, code, top + 1);
    }

    // Traverse right (add 1)
    if (root->right) {
        code[top] = '1';
        printCodes(root->right, code, top + 1);
    }
}

// Function to build the Huffman Tree and print codes
void HuffmanCodes(char data[], int freq[], int size) {
    MinHeapNode *left, *right, *top;

    // Create a min-heap
    MinHeap* minHeap = createMinHeap(size);

    // Insert all characters into the min-heap
    for (int i = 0; i < size; i++) {
        insertMinHeap(minHeap, newNode(data[i], freq[i]));
    }

    // Build the Huffman Tree
    while (minHeap->size != 1) {
        // Extract the two nodes with the smallest frequencies
        left = extractMin(minHeap);
        right = extractMin(minHeap);

        // Create a new internal node with frequency equal to the sum
        top = newNode('$', left->freq + right->freq);
        top->left = left;
        top->right = right;

        // Insert the new node back into the heap
        insertMinHeap(minHeap, top);
    }

    // Print the Huffman codes
    char code[MAX_HEIGHT];
    printCodes(minHeap->array[0], code, 0);

    // Free the min-heap memory
    free(minHeap->array);
    free(minHeap);
}

int main() {
    char arr[] = {'a', 'b', 'c', 'd', 'e', 'f'};
    int freq[] = {5, 9, 12, 13, 16, 45};
    int size = sizeof(arr) / sizeof(arr[0]);

    printf("Huffman Codes:\n");
    HuffmanCodes(arr, freq, size);

    return 0;
}