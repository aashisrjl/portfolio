#include <stdio.h>

// Fibonacci Sequence (Iterative)
int fibonacci(int n) {
    if (n <= 1) return n;
    int a = 0, b = 1, c;
    for (int i = 2; i <= n; i++) {
        c = a + b;
        a = b;
        b = c;
    }
    return b;
}
// Time Complexity: O(n)
// Space Complexity: O(1)

int main() {
    // Fibonacci Example
    int n;
    printf("Enter a non-negative integer: ");
    scanf("%d", &n);
    printf("Fibonacci of %d is: %d\n", n, fibonacci(n));
    return 0;
}
