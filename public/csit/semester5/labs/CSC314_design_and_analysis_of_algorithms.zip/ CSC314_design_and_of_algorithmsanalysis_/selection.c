#include <stdio.h>
#include <time.h>
// Function to swap two elements
void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

// Function to print the array
void printArray(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

// Selection Sort implementation
void selectionSort(int arr[], int size) {
    for (int i = 0; i < size - 1; i++) {
        // Find the minimum element in the unsorted part of the array
        int minIndex = i;
        for (int j = i + 1; j < size; j++) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        // Swap the found minimum element with the first element of the unsorted part
        swap(&arr[i], &arr[minIndex]);
    }
}

int main() {
    int size;
    clock_t start, end;
    double time_taken;
    // Input the size of the array
    printf("Enter the size of the array: ");
    scanf("%d", &size);
    
    int arr[size];
    // Input the array elements
    printf("Enter %d elements:\n", size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &arr[i]);
    }
    
    // Print the original array
    printf("\nOriginal array: ");
    printArray(arr, size);
    
    start = clock();
    // Sort the array using Selection Sort
    selectionSort(arr, size);
    
    end = clock();
    time_taken = ((double)(end - start)) / CLOCKS_PER_SEC;
    // Print the sorted array
    printf("Sorted array (Selection Sort): ");
    printArray(arr, size);
    printf("Time taken for Selection Sort: %f seconds\n", time_taken);
    
    return 0;
}