#include <stdio.h>

// Function to implement the Euclidean Algorithm
// This function returns the GCD of a and b
int gcd(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

// Function to implement the Extended Euclidean Algorithm
// This function returns the GCD of a and b and also computes x and y
// such that ax + by = gcd(a, b)
int extendedGCD(int a, int b, int *x, int *y) {
    if (b == 0) {
        *x = 1;
        *y = 0;
        return a;
    }

    int x1, y1;
    int gcd_result = extendedGCD(b, a % b, &x1, &y1);

    // Update x and y using the results of the recursive call
    *x = y1;
    *y = x1 - (a / b) * y1;

    return gcd_result;
}

int main() {
    int a, b;
    printf("Enter two numbers (a and b) to compute GCD and Extended GCD: ");
    scanf("%d %d", &a, &b);

    // Calculate GCD using the Euclidean algorithm
    int gcd_result = gcd(a, b);
    printf("GCD of %d and %d is: %d\n", a, b, gcd_result);

    // Calculate Extended GCD to find x and y
    int x, y;
    int extended_gcd_result = extendedGCD(a, b, &x, &y);
    printf("Extended GCD of %d and %d is: %d\n", a, b, extended_gcd_result);
    printf("Coefficients x and y are: %d and %d, such that %d * %d + %d * %d = %d\n", x, y, a, x, b, y, extended_gcd_result);

    return 0;
}
