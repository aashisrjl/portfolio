#include <stdio.h>
#include <stdint.h>
#include <string.h>

#define AES_BLOCK_SIZE 16  // 128-bit block size
#define AES_KEY_SIZE 16    // 128-bit key size
#define ROUNDS 10          // Number of rounds for AES-128

// Substitution Box (S-box)
uint8_t S_BOX[16][16] = {
    {0x63, 0x7C, 0x77, 0x7B, 0xF0, 0x87, 0x31, 0xC7, 0xC5, 0xF5, 0x02, 0x7F, 0x67, 0x2B, 0xFE, 0xD7},
    {0xAB, 0x76, 0xCA, 0x82, 0xC9, 0x7D, 0xFA, 0x59, 0x47, 0xF0, 0xAD, 0xD4, 0xA2, 0xAF, 0x9C, 0xA8},
    {0x51, 0xA3, 0x40, 0x8F, 0x92, 0x9D, 0x38, 0xF5, 0xBC, 0xB6, 0xDA, 0x21, 0x10, 0xFF, 0x1F, 0x87},
    {0xC9, 0xB1, 0x17, 0xB4, 0x8B, 0x9E, 0x54, 0x27, 0x1C, 0xA6, 0xDD, 0x5F, 0x4E, 0xA9, 0xC4, 0x73},
    {0x1B, 0x8B, 0x58, 0xEF, 0xB3, 0x4B, 0x8C, 0x30, 0x6A, 0xA7, 0xF6, 0xA4, 0xEC, 0xB2, 0x44, 0x9A},
    {0xA1, 0x3D, 0x34, 0x22, 0x5E, 0x6E, 0x81, 0x67, 0x40, 0x24, 0x1A, 0x5D, 0x6C, 0x99, 0x66, 0x98},
    {0x6B, 0x63, 0x66, 0x9F, 0x7A, 0x2D, 0x81, 0x80, 0xF6, 0xD5, 0xB7, 0xE9, 0x6B, 0xA0, 0x9C, 0x6F},
    {0x7B, 0x3A, 0x3C, 0x3F, 0x35, 0xA8, 0x8D, 0x62, 0x69, 0xA5, 0xB3, 0x42, 0x4D, 0x53, 0x45, 0x1F},
};

// Round constant for AES key expansion
uint8_t RCON[11] = {
    0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1B, 0x36
};

// Function to multiply two numbers in GF(2^8) (used in AES)
uint8_t xtime(uint8_t x) {
    return (x << 1) ^ ((x & 0x80) ? 0x1b : 0x00);
}

// Key expansion (only 128-bit key size supported in this implementation)
void key_expansion(uint8_t *key, uint8_t *round_keys) {
    uint8_t temp[4];
    uint8_t i = 0;
    
    // Copy the original key into the first round key
    for (i = 0; i < AES_KEY_SIZE; i++) {
        round_keys[i] = key[i];
    }

    i = AES_KEY_SIZE;
    while (i < 176) {
        for (int j = 0; j < 4; j++) {
            temp[j] = round_keys[i - 4 + j];
        }

        if (i % AES_KEY_SIZE == 0) {
            // RotWord and SubWord
            uint8_t t = temp[0];
            temp[0] = S_BOX[temp[1] / 16][temp[1] % 16];
            temp[1] = S_BOX[temp[2] / 16][temp[2] % 16];
            temp[2] = S_BOX[temp[3] / 16][temp[3] % 16];
            temp[3] = S_BOX[t / 16][t % 16];

            temp[0] ^= RCON[i / AES_KEY_SIZE];
        }

        for (int j = 0; j < 4; j++) {
            round_keys[i] = round_keys[i - AES_KEY_SIZE] ^ temp[j];
            i++;
        }
    }
}

// Substitution Step (SubBytes)
void sub_bytes(uint8_t *state) {
    for (int i = 0; i < AES_BLOCK_SIZE; i++) {
        state[i] = S_BOX[state[i] / 16][state[i] % 16];
    }
}

// Shift Rows step
void shift_rows(uint8_t *state) {
    uint8_t temp;

    // Row 1 (Shift 1)
    temp = state[1];
    state[1] = state[5];
    state[5] = state[9];
    state[9] = state[13];
    state[13] = temp;

    // Row 2 (Shift 2)
    temp = state[2];
    state[2] = state[10];
    state[10] = temp;
    temp = state[6];
    state[6] = state[14];
    state[14] = temp;

    // Row 3 (Shift 3)
    temp = state[3];
    state[3] = state[15];
    state[15] = state[11];
    state[11] = state[7];
    state[7] = temp;
}

// Mix Columns step
void mix_columns(uint8_t *state) {
    uint8_t temp[16];
    for (int i = 0; i < 4; i++) {
        temp[i * 4] = xtime(state[i * 4] ^ state[i * 4 + 1]) ^ state[i * 4 + 1] ^ state[i * 4 + 2] ^ state[i * 4 + 3];
        temp[i * 4 + 1] = state[i * 4] ^ xtime(state[i * 4 + 1] ^ state[i * 4 + 2]) ^ state[i * 4 + 2] ^ state[i * 4 + 3];
        temp[i * 4 + 2] = state[i * 4] ^ state[i * 4 + 1] ^ xtime(state[i * 4 + 2] ^ state[i * 4 + 3]) ^ state[i * 4 + 3];
        temp[i * 4 + 3] = state[i * 4] ^ state[i * 4 + 1] ^ state[i * 4 + 2] ^ xtime(state[i * 4 + 3]);
    }
    memcpy(state, temp, 16);
}

// AddRoundKey step
void add_round_key(uint8_t *state, uint8_t *round_key) {
    for (int i = 0; i < AES_BLOCK_SIZE; i++) {
        state[i] ^= round_key[i];
    }
}

// AES encryption process
void aes_encrypt(uint8_t *plaintext, uint8_t *key, uint8_t *ciphertext) {
    uint8_t round_keys[176];
    uint8_t state[16];

    // Key Expansion
    key_expansion(key, round_keys);

    // Initial state
    memcpy(state, plaintext, AES_BLOCK_SIZE);

    // Add Round Key (Initial round)
    add_round_key(state, round_keys);

    // Main rounds
    for (int round = 1; round < ROUNDS; round++) {
        sub_bytes(state);
        shift_rows(state);
        mix_columns(state);
        add_round_key(state, round_keys + round * AES_BLOCK_SIZE);
    }

    // Final round (without MixColumns)
    sub_bytes(state);
    shift_rows(state);
    add_round_key(state, round_keys + ROUNDS * AES_BLOCK_SIZE);

    // Copy the ciphertext
    memcpy(ciphertext, state, AES_BLOCK_SIZE);
}

int main() {
    uint8_t key[AES_KEY_SIZE] = {0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x97, 0x75, 0x46, 0x7f, 0x77, 0x9c};
    uint8_t plaintext[AES_BLOCK_SIZE] = {0x32, 0x88, 0x31, 0x43, 0x30, 0x31, 0x30, 0x30, 0x30, 0x31, 0x30, 0x31, 0x32, 0x30, 0x31, 0x30};
    uint8_t ciphertext[AES_BLOCK_SIZE];

    aes_encrypt(plaintext, key, ciphertext);

    printf("Encrypted Ciphertext: ");
    for (int i = 0; i < AES_BLOCK_SIZE; i++) {
        printf("%02x ", ciphertext[i]);
    }
    printf("\n");

    return 0;
}
