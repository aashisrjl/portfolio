#include <stdio.h>
#include <string.h>

void railFenceE(char *message, int railCount) {
    int messageLength = strlen(message);
    char rails[railCount][messageLength];
    memset(rails, 0, sizeof(rails));
    
    int row = 0, col = 0;
    int direction = 1;
    
    for (int i = 0; i < messageLength; i++) {
        rails[row][col] = message[i];
        col++;
        
        if (row == 0) {
            direction = 1;
        } else if (row == railCount - 1) {
            direction = -1;
        }
        row += direction;
    }
    
    printf("Encrypted message: ");
    for (int i = 0; i < railCount; i++) {
        for (int j = 0; j < messageLength; j++) {
            if (rails[i][j] != 0) {
                printf("%c", rails[i][j]);
            }
        }
    }
    printf("\n");
}

void railFenceD(char *cipher, int railCount) {
    int messageLength = strlen(cipher);
    char rails[railCount][messageLength];
    memset(rails, 0, sizeof(rails));
    
    int row = 0, col = 0;
    int direction = 1;
    
    for (int i = 0; i < messageLength; i++) {
        rails[row][col] = '*';
        col++;
        
        if (row == 0) {
            direction = 1;
        } else if (row == railCount - 1) {
            direction = -1;
        }
        row += direction;
    }
    
    int index = 0;
    for (int i = 0; i < railCount; i++) {
        for (int j = 0; j < messageLength; j++) {
            if (rails[i][j] == '*' && index < messageLength) {
                rails[i][j] = cipher[index++];
            }
        }
    }
    
    row = 0, col = 0, direction = 1;
    char decryptedMessage[messageLength + 1];
    for (int i = 0; i < messageLength; i++) {
        decryptedMessage[i] = rails[row][col];
        col++;
        
        if (row == 0) {
            direction = 1;
        } else if (row == railCount - 1) {
            direction = -1;
        }
        row += direction;
    }
    decryptedMessage[messageLength] = '\0';
    printf("Decrypted message: %s\n", decryptedMessage);
}

int main() {
    char message[1000];
    int railCount;
    
    printf("Enter the message to encrypt: ");
    fgets(message, sizeof(message), stdin);
    message[strcspn(message, "\n")] = '\0';
    
    printf("Enter the rail count: ");
    scanf("%d", &railCount);
    getchar(); // To consume newline character left in buffer
    
    railFenceE(message, railCount);
    
    char encryptedMessage[1000];
    printf("Enter the encrypted message to decrypt: ");
    fgets(encryptedMessage, sizeof(encryptedMessage), stdin);
    encryptedMessage[strcspn(encryptedMessage, "\n")] = '\0';
    
    railFenceD(encryptedMessage, railCount);
    
    return 0;
}

