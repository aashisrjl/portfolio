#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int power(int x, unsigned int y, int p)
{
    int res = 1;   
    x = x % p;      
    while (y > 0)
    {
        // If y is odd, multiply x with result
        if (y & 1)
            res = (res * x) % p;

        // y must be even now
        y = y >> 1; // y = y / 2
        x = (x * x) % p;
    }
    return res;
}


int miillerTest(int d, int n)
{

    int a = 2 + rand() % (n - 4);

    // Compute a^d % n
    int x = power(a, d, n);

    if (x == 1 || x == n - 1)
        return 1;


    while (d != n - 1)
    {
        x = (x * x) % n;
        d *= 2;

        if (x == 1)    return 0;
        if (x == n - 1) return 1;
    }

    // Return composite
    return 0;
}


int isPrime(int n, int k)
{
    // Corner cases
    if (n <= 1 || n == 4) return 0;
    if (n <= 3) return 1;

    // Find r such that n = 2^d * r + 1 for some r >= 1
    int d = n - 1;
    while (d % 2 == 0)
        d /= 2;

    // Iterate given number of 'k' times
    for (int i = 0; i < k; i++)
        if (!miillerTest(d, n))
            return 0;

    return 1;
}

// Driver program
int main()
{
    int k = 4; // Number of iterations

    printf("All primes smaller than 100: \n");
    for (int n = 1; n < 100; n++)
        if (isPrime(n, k))
            printf("%d ", n);

    return 0;
}
