#include <stdio.h>
#include <math.h>

// Function to calculate (x^y) % p using iterative method (modular exponentiation)
int power(int x, unsigned int y, int p)
{
    int res = 1;
    x = x % p;  // Update x if it is more than or equal to p

    while (y > 0)
    {
        // If y is odd, multiply x with result
        if (y & 1)
            res = (res * x) % p;

        // y must be even now
        y = y >> 1;  // y = y / 2
        x = (x * x) % p;
    }
    return res;
}

// Function to check if g is a primitive root modulo n
int isPrimitiveRoot(int g, int n)
{
    // Calculate the value of Euler's Totient Function for n
    int phi = n - 1;

    // Check all powers of g modulo n
    for (int i = 1; i < phi; i++)
    {
        if (power(g, i, n) == 1)
            return 0;  // g is not a primitive root
    }
    return 1;  // g is a primitive root
}

// Function to find the primitive roots modulo n
void findPrimitiveRoots(int n)
{
    printf("Primitive roots modulo %d are: ", n);
    for (int g = 2; g < n; g++)
    {
        if (isPrimitiveRoot(g, n))
        {
            printf("%d ", g);
        }
    }
    printf("\n");
}

int main()
{
    int n;
    printf("Enter a number to find its primitive roots: ");
    scanf("%d", &n);

    // Finding primitive roots modulo n
    findPrimitiveRoots(n);

    return 0;
}
