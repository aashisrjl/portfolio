#include <stdio.h>
#include <math.h>

// Function to compute (base^exponent) % mod
long long modExp(long long base, long long exponent, long long mod) {
    long long result = 1;
    base = base % mod;
    
    while (exponent > 0) {
        if (exponent % 2 == 1) {
            result = (result * base) % mod;
        }
        base = (base * base) % mod;
        exponent = exponent / 2;
    }
    
    return result;
}

int main() {
    long long p, g, a, b, A, B, sharedSecretAlice, sharedSecretBob;

    // Step 1: Agree on a public prime p and base g
    printf("Enter a prime number p: ");
    scanf("%lld", &p);
    printf("Enter a base number g: ");
    scanf("%lld", &g);

    // Step 2: Alice chooses a private key 'a'
    printf("Enter Alice's private key (a): ");
    scanf("%lld", &a);
    
    // Step 3: Bob chooses a private key 'b'
    printf("Enter Bob's private key (b): ");
    scanf("%lld", &b);

    // Step 4: Compute Alice's public key A = (g^a) % p
    A = modExp(g, a, p);
    printf("Alice's public key A: %lld\n", A);

    // Step 5: Compute Bob's public key B = (g^b) % p
    B = modExp(g, b, p);
    printf("Bob's public key B: %lld\n", B);

    // Step 6: Alice computes the shared secret key using Bob's public key B
    sharedSecretAlice = modExp(B, a, p);
    printf("Alice's computed shared secret key: %lld\n", sharedSecretAlice);

    // Step 7: Bob computes the shared secret key using Alice's public key A
    sharedSecretBob = modExp(A, b, p);
    printf("Bob's computed shared secret key: %lld\n", sharedSecretBob);

    // Step 8: Verify if both computed shared keys are the same
    if (sharedSecretAlice == sharedSecretBob) {
        printf("The shared secret keys match! Key: %lld\n", sharedSecretAlice);
    } else {
        printf("The shared secret keys do not match.\n");
    }

    return 0;
}
