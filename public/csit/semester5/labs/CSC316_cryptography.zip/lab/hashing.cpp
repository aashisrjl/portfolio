#include <stdio.h>
#include <string.h>
#include <openssl/md5.h>
#include <openssl/sha.h>
#include <openssl/md4.h>

// Function to print the hash in hexadecimal format
void print_hash(unsigned char *hash, int length) {
    for (int i = 0; i < length; i++) {
        printf("%02x", hash[i]);
    }
    printf("\n");
}

int main() {
    // Sample input string to be hashed
    char input[] = "Hello, World!";
    
    unsigned char md4_hash[MD4_DIGEST_LENGTH];
    unsigned char md5_hash[MD5_DIGEST_LENGTH];
    unsigned char sha1_hash[SHA_DIGEST_LENGTH];
    unsigned char sha256_hash[SHA256_DIGEST_LENGTH];

    MD4 Hashing
    MD4_CTX md4_ctx;
    MD4_Init(&md4_ctx);
    MD4_Update(&md4_ctx, input, strlen(input));
    MD4_Final(md4_hash, &md4_ctx);
    printf("MD4 Hash: ");
    print_hash(md4_hash, MD4_DIGEST_LENGTH);

    // MD5 Hashing
    MD5_CTX md5_ctx;
    MD5_Init(&md5_ctx);
    MD5_Update(&md5_ctx, input, strlen(input));
    MD5_Final(md5_hash, &md5_ctx);
    printf("MD5 Hash: ");
    print_hash(md5_hash, MD5_DIGEST_LENGTH);

    // SHA-1 Hashing
    SHA_CTX sha1_ctx;
    SHA1_Init(&sha1_ctx);
    SHA1_Update(&sha1_ctx, input, strlen(input));
    SHA1_Final(sha1_hash, &sha1_ctx);
    printf("SHA-1 Hash: ");
    print_hash(sha1_hash, SHA_DIGEST_LENGTH);

    // SHA-256 Hashing
    SHA256_CTX sha256_ctx;
    SHA256_Init(&sha256_ctx);
    SHA256_Update(&sha256_ctx, input, strlen(input));
    SHA256_Final(sha256_hash, &sha256_ctx);
    printf("SHA-256 Hash: ");
    print_hash(sha256_hash, SHA256_DIGEST_LENGTH);

    return 0;
}
