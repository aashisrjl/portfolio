#include <stdio.h>
#include <string.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/sha.h>
#include <openssl/err.h>

// Function to print the error message
void handle_errors() {
    ERR_print_errors_fp(stderr);
    exit(1);
}

// Function to print the signature in hexadecimal format
void print_hex(unsigned char *data, size_t length) {
    for (size_t i = 0; i < length; i++) {
        printf("%02x", data[i]);
    }
    printf("\n");
}

// RSA key generation
RSA *generate_RSA_keys() {
    RSA *rsa = RSA_new();
    BIGNUM *bne = BN_new();

    if (BN_set_word(bne, RSA_F4) != 1) {
        handle_errors();
    }

    if (RSA_generate_key_ex(rsa, 2048, bne, NULL) != 1) {
        handle_errors();
    }

    BN_free(bne);
    return rsa;
}

// Signing the message
int sign_message(RSA *private_key, const unsigned char *message, unsigned char *signature) {
    unsigned char hash[SHA256_DIGEST_LENGTH];

    // Hash the message using SHA-256
    SHA256_CTX sha256_ctx;
    SHA256_Init(&sha256_ctx);
    SHA256_Update(&sha256_ctx, message, strlen((const char *)message));
    SHA256_Final(hash, &sha256_ctx);

    // Sign the hash using the private key
    unsigned int sig_len;
    if (RSA_sign(NID_sha256, hash, SHA256_DIGEST_LENGTH, signature, &sig_len, private_key) != 1) {
        handle_errors();
    }

    return sig_len;
}

// Verifying the signature
int verify_signature(RSA *public_key, const unsigned char *message, unsigned char *signature, unsigned int sig_len) {
    unsigned char hash[SHA256_DIGEST_LENGTH];

    // Hash the message using SHA-256
    SHA256_CTX sha256_ctx;
    SHA256_Init(&sha256_ctx);
    SHA256_Update(&sha256_ctx, message, strlen((const char *)message));
    SHA256_Final(hash, &sha256_ctx);

    // Verify the signature
    if (RSA_verify(NID_sha256, hash, SHA256_DIGEST_LENGTH, signature, sig_len, public_key) != 1) {
        return 0; // Signature verification failed
    }

    return 1; // Signature verification succeeded
}

int main() {
    // Generate RSA keys (private and public)
    RSA *rsa = generate_RSA_keys();
    if (rsa == NULL) {
        handle_errors();
    }

    // The message to be signed
    const unsigned char *message = (unsigned char *)"This is a test message for RSA digital signature.";

    // Sign the message
    unsigned char signature[256];
    int sig_len = sign_message(rsa, message, signature);

    // Print the digital signature
    printf("Digital Signature (Hex):\n");
    print_hex(signature, sig_len);

    // Verify the signature using the public key
    if (verify_signature(rsa, message, signature, sig_len)) {
        printf("Signature verification successful.\n");
    } else {
        printf("Signature verification failed.\n");
    }

    // Clean up
    RSA_free(rsa);

    return 0;
}
