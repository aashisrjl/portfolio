#include <stdio.h>
#include <string.h>
#include <openssl/dsa.h>
#include <openssl/pem.h>
#include <openssl/sha.h>

void print_hex(unsigned char *hash, size_t length) {
    for (size_t i = 0; i < length; i++) {
        printf("%02x", hash[i]);
    }
    printf("\n");
}

int main() {
    // Step 1: Generate DSA keys
    DSA *dsa = DSA_new();
    if (!DSA_generate_parameters_ex(dsa, 2048, NULL, 0, NULL, NULL, NULL)) {
        fprintf(stderr, "DSA parameter generation failed.\n");
        return 1;
    }

    if (!DSA_generate_key(dsa)) {
        fprintf(stderr, "DSA key generation failed.\n");
        return 1;
    }

    // Step 2: Extract private and public keys
    unsigned char *private_key;
    int private_key_len = i2d_DSAPrivateKey(dsa, &private_key);

    unsigned char *public_key;
    int public_key_len = i2d_DSAPublicKey(dsa, &public_key);

    // Print private and public keys in hex format
    printf("Private Key (Hex):\n");
    print_hex(private_key, private_key_len);
    
    printf("Public Key (Hex):\n");
    print_hex(public_key, public_key_len);

    // Step 3: Sign a message with the private key
    const char *message = "This is a test message for DSA!";
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256_CTX sha256_ctx;

    // Hash the message using SHA-256
    SHA256_Init(&sha256_ctx);
    SHA256_Update(&sha256_ctx, message, strlen(message));
    SHA256_Final(hash, &sha256_ctx);

    // Create a digital signature with the private key
    unsigned char *sig;
    unsigned int sig_len;
    if (DSA_sign(0, hash, SHA256_DIGEST_LENGTH, sig, &sig_len, dsa) == 0) {
        fprintf(stderr, "Signing failed.\n");
        return 1;
    }

    printf("Digital Signature (Hex):\n");
    print_hex(sig, sig_len);

    // Step 4: Verify the digital signature using the public key
    if (DSA_verify(0, hash, SHA256_DIGEST_LENGTH, sig, sig_len, dsa) == 1) {
        printf("Signature verification successful.\n");
    } else {
        printf("Signature verification failed.\n");
    }

    // Clean up
    DSA_free(dsa);
    OPENSSL_free(private_key);
    OPENSSL_free(public_key);
    OPENSSL_free(sig);

    return 0;
}


