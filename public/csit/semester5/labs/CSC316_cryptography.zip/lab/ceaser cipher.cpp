#include <stdio.h>
#include <string.h>
#include <ctype.h>

void encrypt(char *text, int k, char *encrypted) {
    for (int i = 0; i < strlen(text); i++) {
        if (isupper(text[i])) {
            encrypted[i] = (text[i] + k - 65) % 26 + 65;
        } else if (islower(text[i])) {
            encrypted[i] = (text[i] + k - 97) % 26 + 97;
        } else {
            encrypted[i] = text[i];  // Handle non-alphabetic characters
        }
    }
    encrypted[strlen(text)] = '\0';  // Null-terminate the string
}

void decrypt(char *text, int k, char *decrypted) {
    for (int i = 0; i < strlen(text); i++) {
        if (isupper(text[i])) {
            decrypted[i] = (text[i] - k - 65 + 26) % 26 + 65;
        } else if (islower(text[i])) {
            decrypted[i] = (text[i] - k - 97 + 26) % 26 + 97;
        } else {
            decrypted[i] = text[i];  // Handle non-alphabetic characters
        }
    }
    decrypted[strlen(text)] = '\0';  // Null-terminate the string
}

int main() {
    int k;
    char text[100], encrypted[100], decrypted[100];
    
    printf("Enter a plaintext:\n");
    fgets(text, sizeof(text), stdin);
    text[strcspn(text, "\n")] = '\0';  // Remove the trailing newline character from input

    printf("\nEnter a key:\n");
    scanf("%d", &k);

    encrypt(text, k, encrypted);
    printf("Encrypted result is:\n%s\n", encrypted);
    
    char yes;
    printf("\nDo you want to decrypt this text? If yes, press (y/n): ");
    scanf(" %c", &yes);  // Notice the space before %c to capture the newline character

    if (yes == 'y') {
        decrypt(encrypted, k, decrypted);
        printf("Decrypted result is:\n%s\n", decrypted);
    } else {
        printf("\nThank you!\n");
    }

    return 0;
}
