#include <stdio.h>

// Function to calculate the greatest common divisor (GCD) of two numbers
int gcd(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

// Function to compute Euler's Totient Function φ(n)
int euler_totient(int n) {
    int result = n;
    
    // Iterate over all numbers less than n to find the prime factors
    for (int p = 2; p * p <= n; p++) {
        // Check if p is a divisor of n
        if (n % p == 0) {
            // If it is, we subtract multiples of p from result
            while (n % p == 0) {
                n /= p;
            }
            result -= result / p;
        }
    }
    
    // If n is a prime number greater than 1
    if (n > 1) {
        result -= result / n;
    }
    
    return result;
}

// Driver program
int main() {
    int n;
    
    printf("Enter a number: ");
    scanf("%d", &n);
    
    // Calculate Euler's Totient Function φ(n)
    int result = euler_totient(n);
    
    printf("Euler's Totient Function φ(%d) = %d\n", n, result);
    
    return 0;
}
