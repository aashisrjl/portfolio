#include <stdio.h>

// Function to compute (base^exponent) % mod
int modExp(int base, int exponent, int mod) {
    int result = 1;
    base = base % mod;
    
    while (exponent > 0) {
        if (exponent % 2 == 1) {
            result = (result * base) % mod;
        }
        base = (base * base) % mod;
        exponent = exponent / 2;
    }
    
    return result;
}

// Function to find the discrete logarithm
// g^x ≡ h (mod p)
int discreteLog(int g, int h, int p) {
    for (int x = 0; x < p; x++) {
        if (modExp(g, x, p) == h) {
            return x;
        }
    }
    return -1; // If no solution is found
}

int main() {
    int g, h, p;
    
    // Input values
    printf("Enter the value of base g: ");
    scanf("%d", &g);
    printf("Enter the value of result h: ");
    scanf("%d", &h);
    printf("Enter the value of prime modulus p: ");
    scanf("%d", &p);
    
    // Find the discrete logarithm
    int result = discreteLog(g, h, p);
    
    if (result != -1) {
        printf("Discrete logarithm x is: %d\n", result);
    } else {
        printf("No solution exists for the given values.\n");
    }
    
    return 0;
}
