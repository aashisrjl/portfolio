#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// Function to compute (base^exponent) % mod
long long modExp(long long base, long long exponent, long long mod) {
    long long result = 1;
    base = base % mod;
    while (exponent > 0) {
        if (exponent % 2 == 1) {
            result = (result * base) % mod;
        }
        base = (base * base) % mod;
        exponent = exponent / 2;
    }
    return result;
}

// Function to compute gcd of two numbers
long long gcd(long long a, long long b) {
    while (b != 0) {
        long long temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

// Function to compute modular inverse of a under modulo m
long long modInverse(long long a, long long m) {
    for (long long x = 2; x < m; x++) {
        if ((a * x) % m == 1)
            return x;
    }
    return -1;
}

// ElGamal Key Generation
void generateElGamalKeys(long long *p, long long *g, long long *h, long long *x) {
    *p = 23;  // A small prime number for p
    *g = 5;   // A primitive root modulo p
    *x = 15;  // Private key, chosen randomly

    // Compute public key h = g^x mod p
    *h = modExp(*g, *x, *p);
}

// ElGamal Encryption
void encrypt(long long m, long long p, long long g, long long h, long long *c1, long long *c2) {
    long long y = rand() % (p - 1) + 1;  // Random value for y, 1 <= y < p-1
    *c1 = modExp(g, y, p);  // c1 = g^y mod p
    *c2 = (m * modExp(h, y, p)) % p;  // c2 = m * h^y mod p
}

// ElGamal Decryption
long long decrypt(long long c1, long long c2, long long p, long long x) {
    // Compute s = c1^x mod p
    long long s = modExp(c1, x, p);
    
    // Find modular inverse of s modulo p
    long long s_inv = modInverse(s, p);
    
    // Decrypt message m = c2 * s_inv mod p
    long long m = (c2 * s_inv) % p;
    return m;
}

int main() {
    long long p, g, h, x;
    long long c1, c2;
    long long message, decryptedMessage;

    // Step 1: Generate ElGamal keys
    generateElGamalKeys(&p, &g, &h, &x);
    printf("ElGamal Public Key: (p = %lld, g = %lld, h = %lld)\n", p, g, h);
    printf("ElGamal Private Key: x = %lld\n", x);

    // Step 2: Encrypt a message
    message = 13;  // Example message
    encrypt(message, p, g, h, &c1, &c2);
    printf("Encrypted Message: (c1 = %lld, c2 = %lld)\n", c1, c2);

    // Step 3: Decrypt the message
    decryptedMessage = decrypt(c1, c2, p, x);
    printf("Decrypted Message: %lld\n", decryptedMessage);

    return 0;
}
