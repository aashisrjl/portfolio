#include <stdio.h>
#include <openssl/pem.h>
#include <openssl/rsa.h>
#include <openssl/sha.h>
#include <openssl/pkcs7.h>
#include <openssl/x509.h>
#include <openssl/x509v3.h>

void generate_keys(const char *private_key_file, const char *public_key_file) {
    RSA *keypair = RSA_generate_key(2048, RSA_F4, NULL, NULL);

    // Write the private key to a file
    FILE *private_key_fp = fopen(private_key_file, "wb");
    PEM_write_RSAPrivateKey(private_key_fp, keypair, NULL, NULL, 0, NULL, NULL);
    fclose(private_key_fp);

    // Write the public key to a file
    FILE *public_key_fp = fopen(public_key_file, "wb");
    PEM_write_RSA_PUBKEY(public_key_fp, keypair);
    fclose(public_key_fp);

    RSA_free(keypair);
}

void sign_message(const char *message, const char *private_key_file, const char *signature_file) {
    FILE *private_key_fp = fopen(private_key_file, "rb");
    RSA *rsa_private_key = PEM_read_RSAPrivateKey(private_key_fp, NULL, NULL, NULL);
    fclose(private_key_fp);

    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256_CTX sha256_ctx;
    SHA256_Init(&sha256_ctx);
    SHA256_Update(&sha256_ctx, message, strlen(message));
    SHA256_Final(hash, &sha256_ctx);

    unsigned char *signature = malloc(RSA_size(rsa_private_key));
    unsigned int signature_len = 0;

    if (RSA_sign(NID_sha256, hash, SHA256_DIGEST_LENGTH, signature, &signature_len, rsa_private_key) != 1) {
        printf("Error signing message\n");
        free(signature);
        RSA_free(rsa_private_key);
        return;
    }

    // Save the signature to a file
    FILE *signature_fp = fopen(signature_file, "wb");
    fwrite(signature, 1, signature_len, signature_fp);
    fclose(signature_fp);

    free(signature);
    RSA_free(rsa_private_key);
}

int main() {
    const char *private_key_file = "private_key.pem";
    const char *public_key_file = "public_key.pem";
    const char *message = "This is a test email message to be signed using RSA and OpenSSL.";
    const char *signature_file = "signature.sig";

    // Step 1: Generate RSA keys
    generate_keys(private_key_file, public_key_file);

    // Step 2: Sign the message
    sign_message(message, private_key_file, signature_file);

    printf("Message signed successfully and saved in %s\n", signature_file);

    return 0;
}
