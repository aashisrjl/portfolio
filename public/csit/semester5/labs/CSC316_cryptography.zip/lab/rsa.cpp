#include <stdio.h>
#include <math.h>

// Function to compute gcd of two numbers
long long gcd(long long a, long long b) {
    while (b != 0) {
        long long temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

// Function to compute (base^exponent) % mod
long long modExp(long long base, long long exponent, long long mod) {
    long long result = 1;
    base = base % mod;

    while (exponent > 0) {
        if (exponent % 2 == 1) {
            result = (result * base) % mod;
        }
        base = (base * base) % mod;
        exponent = exponent / 2;
    }
    return result;
}

// Function to compute modular multiplicative inverse of e under modulo m
long long modInverse(long long e, long long m) {
    for (long long d = 2; d < m; d++) {
        if ((e * d) % m == 1)
            return d;
    }
    return -1; // Return -1 if no inverse is found
}

// Function to generate RSA keys
void generateRSAKeys(long long *n, long long *e, long long *d) {
    long long p = 61;  // A small prime number for p
    long long q = 53;  // A small prime number for q
    *n = p * q;
    long long phi = (p - 1) * (q - 1);  // Euler's totient function

    // Choose e such that 1 < e < phi and gcd(e, phi) = 1
    *e = 17; // A commonly used public exponent

    // Calculate d such that (e * d) % phi = 1
    *d = modInverse(*e, phi);
}

// Function to encrypt a message using RSA encryption
long long encrypt(long long message, long long e, long long n) {
    return modExp(message, e, n);
}

// Function to decrypt a message using RSA decryption
long long decrypt(long long ciphertext, long long d, long long n) {
    return modExp(ciphertext, d, n);
}

int main() {
    long long n, e, d;

    // Step 1: Generate RSA Keys
    generateRSAKeys(&n, &e, &d);
    printf("RSA Public Key: (e = %lld, n = %lld)\n", e, n);
    printf("RSA Private Key: (d = %lld, n = %lld)\n", d, n);

    // Step 2: Encrypt a message
    long long message = 65; // Example message
    long long ciphertext = encrypt(message, e, n);
    printf("Encrypted Message: %lld\n", ciphertext);

    // Step 3: Decrypt the message
    long long decryptedMessage = decrypt(ciphertext, d, n);
    printf("Decrypted Message: %lld\n", decryptedMessage);

    return 0;
}
