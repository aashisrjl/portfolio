#include <stdio.h>
#include <stdint.h>
#include <string.h>

#define BLOCK_SIZE 8
#define ROUNDS 8

// Utility function for modulo multiplication
uint16_t mod_mult(uint16_t a, uint16_t b, uint16_t mod) {
    uint32_t result = (uint32_t)a * b;
    return (uint16_t)(result % mod);
}

// Utility function for modulo addition
uint16_t mod_add(uint16_t a, uint16_t b, uint16_t mod) {
    return (a + b) % mod;
}

// Key generation function
void generate_round_keys(uint8_t *key, uint16_t round_keys[ROUNDS][6]) {
    int i;
    uint16_t temp_key[8];
    
    // Divide the 128-bit key into 8 16-bit segments
    for (i = 0; i < 8; i++) {
        temp_key[i] = (key[2 * i] << 8) + key[2 * i + 1];
    }
    
    // Generate round keys (for simplification, we won't show the exact key schedule here)
    // IDEA uses specific rotations and transformations for key scheduling
    // For a full implementation, key scheduling should follow the actual algorithm

    // Example round key generation (simplified and not complete)
    for (i = 0; i < ROUNDS; i++) {
        for (int j = 0; j < 6; j++) {
            round_keys[i][j] = temp_key[j % 8];
        }
    }
}

// Encryption function
void idea_encrypt(uint8_t *plaintext, uint8_t *ciphertext, uint16_t round_keys[ROUNDS][6]) {
    uint16_t x[4], z[4];
    int i, j;
    
    // Convert plaintext from bytes to 16-bit blocks
    for (i = 0; i < 4; i++) {
        x[i] = (plaintext[2 * i] << 8) + plaintext[2 * i + 1];
    }
    
    // Perform 8 rounds of encryption
    for (i = 0; i < ROUNDS; i++) {
        // Apply transformations using round keys (modular additions and multiplications)
        for (j = 0; j < 4; j++) {
            z[j] = x[j];
        }

        x[0] = mod_add(mod_mult(z[0], round_keys[i][0], 0x10001), round_keys[i][1], 0x10000);
        x[1] = mod_add(mod_mult(z[1], round_keys[i][2], 0x10001), round_keys[i][3], 0x10000);
        x[2] = mod_add(mod_mult(z[2], round_keys[i][4], 0x10001), round_keys[i][5], 0x10000);
        
        // XOR operations
        x[0] ^= x[1];
        x[2] ^= x[3];
    }

    // Output ciphertext
    for (i = 0; i < 4; i++) {
        ciphertext[2 * i] = x[i] >> 8;
        ciphertext[2 * i + 1] = x[i] & 0xFF;
    }
}

// Decryption function (reverse the encryption process)
void idea_decrypt(uint8_t *ciphertext, uint8_t *plaintext, uint16_t round_keys[ROUNDS][6]) {
    uint16_t x[4], z[4];
    int i, j;
    
    // Convert ciphertext from bytes to 16-bit blocks
    for (i = 0; i < 4; i++) {
        x[i] = (ciphertext[2 * i] << 8) + ciphertext[2 * i + 1];
    }
    
    // Perform 8 rounds of decryption (reverse the encryption steps)
    for (i = 0; i < ROUNDS; i++) {
        // Apply transformations using reverse round keys (reverse modular additions and multiplications)
        for (j = 0; j < 4; j++) {
            z[j] = x[j];
        }
        
        x[0] = mod_add(mod_mult(z[0], round_keys[i][0], 0x10001), round_keys[i][1], 0x10000);
        x[1] = mod_add(mod_mult(z[1], round_keys[i][2], 0x10001), round_keys[i][3], 0x10000);
        x[2] = mod_add(mod_mult(z[2], round_keys[i][4], 0x10001), round_keys[i][5], 0x10000);

        // XOR operations
        x[0] ^= x[1];
        x[2] ^= x[3];
    }
    
    // Output plaintext
    for (i = 0; i < 4; i++) {
        plaintext[2 * i] = x[i] >> 8;
        plaintext[2 * i + 1] = x[i] & 0xFF;
    }
}

// Main function to demonstrate IDEA encryption and decryption
int main() {
    uint8_t key[16] = { 0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0x4f, 0x3c, 0xa4, 0x8c, 0x78, 0x4e, 0x65, 0x8b };
    uint8_t plaintext[BLOCK_SIZE] = { 0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d };
    uint8_t ciphertext[BLOCK_SIZE];
    uint8_t decryptedtext[BLOCK_SIZE];

    uint16_t round_keys[ROUNDS][6];
    
    // Generate round keys from the 128-bit key
    generate_round_keys(key, round_keys);
    
    // Encrypt the plaintext
    idea_encrypt(plaintext, ciphertext, round_keys);
    
    printf("Ciphertext: ");
    for (int i = 0; i < BLOCK_SIZE; i++) {
        printf("%02x ", ciphertext[i]);
    }
    printf("\n");

    // Decrypt the ciphertext
    idea_decrypt(ciphertext, decryptedtext, round_keys);

    printf("Decrypted text: ");
    for (int i = 0; i < BLOCK_SIZE; i++) {
        printf("%02x ", decryptedtext[i]);
    }
    printf("\n");

    return 0;
}
