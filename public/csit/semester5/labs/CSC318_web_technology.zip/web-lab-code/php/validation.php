<?php
$usernameError = $emailError = $passwordError = $confirmPasswordError = $termsError = "";
$username = $email = $password = $confirmPassword = $terms = "";
$isSubmitted = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);
    $confirmPassword = trim($_POST["confirmPassword"]);
    $terms = isset($_POST["terms"]) ? $_POST["terms"] : '';

    $isValid = true;

    // Validate Username
    if (empty($username)) {
        $usernameError = "Username is required.";
        $isValid = false;
    }

    // Validate Email
    if (empty($email)) {
        $emailError = "Email is required.";
        $isValid = false;
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailError = "Please enter a valid email address.";
        $isValid = false;
    }

    // Validate Password
    if (empty($password)) {
        $passwordError = "Password is required.";
        $isValid = false;
    } elseif (strlen($password) < 6) {
        $passwordError = "Password must be at least 6 characters long.";
        $isValid = false;
    }

    // Validate Confirm Password
    if (empty($confirmPassword)) {
        $confirmPasswordError = "Confirm Password is required.";
        $isValid = false;
    } elseif ($password !== $confirmPassword) {
        $confirmPasswordError = "Passwords do not match.";
        $isValid = false;
    }

    // Validate Terms and Conditions
    if (empty($terms)) {
        $termsError = "You must agree to the terms and conditions.";
        $isValid = false;
    }

    // If all validations pass
    if ($isValid) {
        $isSubmitted = true;
        // Proceed with further processing (e.g., storing data in a database)
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Server-side Form Validation</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h2>Registration Form</h2>
    <?php if ($isSubmitted): ?>
        <p>Form submitted successfully!</p>
    <?php else: ?>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>">
            <div class="error"><?php echo $usernameError; ?></div>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>">
            <div class="error"><?php echo $emailError; ?></div>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password">
            <div class="error"><?php echo $passwordError; ?></div>

            <label for="confirmPassword">Confirm Password:</label>
            <input type="password" id="confirmPassword" name="confirmPassword">
            <div class="error"><?php echo $confirmPasswordError; ?></div>

            <label>
                <input type="checkbox" id="terms" name="terms" <?php if ($terms) echo "checked"; ?>>
                I agree to the terms and conditions
            </label>
            <div class="error"><?php echo $termsError; ?></div>

            <button type="submit">Register</button>
        </form>
    <?php endif; ?>
</body>
</html>